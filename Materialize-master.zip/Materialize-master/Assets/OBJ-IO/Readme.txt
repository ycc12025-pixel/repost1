       
/* * * * * * * * * * * * Author's note * * * * * * * * * * * * * *\
*                                                                 *
*                         ZZ$$Z$$$$Z$$$                           *
*                         ZZZZZZZZZZZZZ                           *
*                         ZZZZZZZZZZZZZ                           *
*                         $ZZZZZZZZZZZZ                           *
*                         $ZZZZZZZZZZZZ                           *
*                         ZZ7=$OOO$?$ZO                           *
*                         Z7   $OZ   IO                           *
*                 ZZZZZZZZOOOZOOOOOZZ8OZZZZZZZZZ                  *
*                NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO                  *
*                NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO                  *
*            8O8OOOOO8    88O88O8888888    D88888888              *
*            8OOOOOOO8    8OOON    OO88    DO8888888              *
*            DDDDDDDDD    DDDD     DDDD    NDDDDDDDD              *
*                                                                 *
*                    http://octo-dev.co.uk                        *
*                                                                 *
*                            OBJ-IO                               *
*                                                                 *
*                    Copyright (c) Octo-Dev                       *
*                                                                 *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

The scripts for this plugin are in [OBJ-IO/Plugins/OBJ] 
and [OBJ-IO/Plugins/Extension].

There is an Example scene that Imports the Teapot OBJ at runtime,
distorts the vertexs and exports it again. The Export and Import 
functions take System.IO.Stream as a parameter so this can be adapted
for your needs.

The System Current only supports geometry.

If there is any issue or bugs please contact : tim.leader.octo@gmail.com